from fastapi import APIRouter

from app.api.v1.endpoints import auth, contracts, health

router = APIRouter()

router.include_router(health.router, prefix="/health", tags=["health"])
router.include_router(auth.router, prefix="/auth", tags=["auth"])
router.include_router(contracts.router, prefix="/contracts", tags=["contracts"])
